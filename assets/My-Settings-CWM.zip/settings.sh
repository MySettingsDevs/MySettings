#!/sbin/sh

# Creating the initiation for ui_print from within a .sh file to recovery ui
# this was created by Chainfire.

# get file descriptor for output
OUTFD=$(ps | grep -v "grep" | grep -o -E "update_binary(.*)" | cut -d " " -f 3);

ui_print() {
  if [ $OUTFD != "" ]; then
    echo "ui_print ${1} " 1>&$OUTFD;
    echo "ui_print " 1>&$OUTFD;
  else
    echo "${1}";
  fi;
}

# --- script for checking pngs ---
ui_print "";
ui_print "  Checking settings";
ui_print "";

batteryicons=$(cat /sdcard/MySettings/YourSettings.sh | grep -e "CM7Icons=true")
if [ $batteryicons = "CM7Icons=true" ]; then
	ui_print "  Installing CM7 Icons";
	cp -rf /sdcard/MySettings/Install-Mods/SystemUI/BatteryIcons/CM7Icons/* /system/app
fi

batteryicons=$(cat /sdcard/MySettings/YourSettings.sh | grep -e "Circle=true")
if [ $batteryicons = "Circle=true" ]; then
	ui_print "  Installing Circle Icons";
	cp -rf /sdcard/MySettings/Install-Mods/SystemUI/BatteryIcons/Circle/* /system/app
fi

batteryicons=$(cat /sdcard/MySettings/YourSettings.sh | grep -e "Quad=true")
if [ $batteryicons = "Quad=true" ]; then
	ui_print "  Installing Quad Icons";
	cp -rf /sdcard/MySettings/Install-Mods/SystemUI/BatteryIcons/Quad/* /system/app
fi

# --- script for checking taskswitcher ---
ui_print "";
taskswitcher=$(cat /sdcard/MySettings/YourSettings.sh | grep -e "CM7taskswitcher=true")
if [ $taskswitcher = "CM7taskswitcher=true" ]; then
	ui_print "  Installing CM7 TaskSwitcher";
	cp -rf /sdcard/MySettings/Install-Mods/framework/CM7/* /system/framework
fi

taskswitcher=$(cat /sdcard/MySettings/YourSettings.sh | grep -e "CM9taskswitcher=true")
if [ $taskswitcher = "CM9taskswitcher=true" ]; then
	ui_print "  Installing CM9 TaskSwitcher";
	cp -rf /sdcard/MySettings/Install-Mods/framework/CM9/* /system/framework
fi

# --- script for deleting choosen SystemApps ---
ui_print "";

FILE_DEL_SYS=/sdcard/MySettings/Delete-Apps/Delete-SystemApps

if [ -d "$FILE_DEL" ]; then
	ui_print " Removing choosen SystemApps ";
	for FILE in "$FILE_DEL_SYS"/*
	do
	DEL_FILE_SYS=`basename "$FILE"`
	rm -f /system/app/$DEL_FILE_SYS
	done
fi

# --- script for deleting choosen UserApps ---
ui_print "";

FILE_DEL_USR=/sdcard/MySettings/Delete-Apps/Delete-UserApps

if [ -d "$FILE_DEL" ]; then
	ui_print " Removing choosen UserApps ";
	for FILE in "$FILE_DEL_USR"/*
	do
	DEL_FILE_USR=`basename "$FILE"`
	rm -f /data/app/$DEL_FILE_USR
	done
fi

# --- script for installing Samsung Apps ---

samsungapps=$(cat /sdcard/MySettings/YourSettings.sh | grep -e "SamsungApps=true")
if [ $samsungapps = "SamsungApps=true" ]; then
	ui_print "  Installing Samsung Apps";
	cp /sdcard/MySettings/Install-Mods/SamsungApps/app/* /system/app
	cp /sdcard/MySettings/Install-Mods/SamsungApps/etc/init.d/* /system/etc/init.d
	cp /sdcard/MySettings/Install-Mods/SamsungApps/framework/* /system/framework
	cp /sdcard/MySettings/Install-Mods/SamsungApps/xbin/* /system/xbin
fi